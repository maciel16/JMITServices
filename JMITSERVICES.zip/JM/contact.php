<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="description=" content="Serviços de Desenvolvimento de Sistemas, Manutenção de Computadores e Design">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Contato</title>
    <link rel="shortcut icon" type="image/x-icon" href="images/logo/favicon.ico">

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- Button Top CSS CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:400,900,900i" rel="stylesheet">

    <!-- Button Top CSS CDN 
    <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.rawgit.com/dwyl/html-form-send-email-via-google-script-without-server/master/style.css">
    -->

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/topbt.css" rel="stylesheet">
    <link href="css/slideshow.css" rel="stylesheet">
    <link href="css/contact.css" rel="stylesheet">
    <link href="css/column.css" rel="stylesheet">
    <link href="css/sidebar.css" rel="stylesheet">
</head>

<body>

    <a id="button"></a>

    <div class="header">
        <h1>JM</h1>
        <p>IT Services</p>
    </div>

    <div class="wrapper">
        <!-- Sidebar Holder -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <a href="index.html">
                    <img alt="Home" src="images/logo/icon.png">
                </a>
            </div>

            <ul class="list-unstyled components">
                <li>
                    <a href="index.html">Home</a>
                    <a href="about.html">Sobre</a>
                    <a href="product1.html">Serviços</a>
                    <a href="portifolio.html">Portfolio</a>
                    <a href="contact.php">Contato</a>
                </li>
            </ul>

            <ul class="list-unstyled CTAs">
                <li><a href="index.html" class="article">Pagina Principal</a></li>
            </ul>
        </nav>



        <!-- Page Content Holder -->
        <div id="content">

            <nav class="navbar navbar-default ">
                <div class="container-fluid">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a>|Contato</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <div id="Content" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Entre em Contato</h2>

            </div>



            <div id="form" class="col-lg-12 col-md-12 col-sm-12">
                <br>
                <div id="contact">

                    <div id="contactform" class="col-lg-12 col-md-12 col-sm-12">
                        <!-- modify this form HTML and place wherever you want your form -->

                        <?php
                        if ($_POST) {
                            //Carrega as classes do PHPMailer
                            include("./phpmailer/class.phpmailer.php");
                            include("./phpmailer/class.smtp.php");
    
                            //envia o e-mail para o visitante do site
                            $mailDestino = $_POST['Email'];
                            $nome = $_POST['Name'];
                            $mensagem = "Olá, $_POST[Name] <br/>
                        Recebemos sua mensagem!<br/>
                        Assim que possível retornaremos o contato.<br/>
                        <br/>
                        Atenciosamente";
                            $assunto = "Obrigado pelo seu contato!";
                            include("./envio.php");
    
                            //envia o e-mail para o administrador do site
                            $mailDestino = 'maciel16.contact@gmail.com';
                            $nome = 'Maciel Contato';
                            $assunto = "Nova Mensagem: $_POST[Subject]";
                            $mensagem = "Recebemos uma nova mensagem no site. <br/>
                        <br/>
                        Segue abaixo informações...
                        <br/>
                        <br/>
                        <strong>Nome:</strong> $_POST[Name]<br/>
                        <strong>E-mail:</strong> $_POST[Email]<br/>
                        <strong>Telefone:</strong> $_POST[CellPhone]<br/>
                        <strong>Como conheceu o Site:</strong> $_POST[HowKUS]<br/>
                        <strong>Assunto:</strong> $_POST[Subject]<br/>
                        <strong>Mensagem:</strong> $_POST[Message]";
                            include("./envio.php");
                        }
                        ?>


                        <form method="POST" name="formContato">
                            <fieldset class="form-group">
                                <label for="name">Nome: </label>
                                <br>
                                <input id="name" name="Name" class="form-control" placeholder="Nome Completo" value=""
                                    required />
                            </fieldset>

                            <fieldset class="form-group">
                                <label>Email:</label>
                                <br>
                                <input type="email" name="Email" value="" class="form-control" required
                                    placeholder="seuemail@gmail.com" />
                                <span id="email-invalid" style="visibility:hidden">
                                    Por favor, informe um E-mail valido.</span>
                            </fieldset>

                            <fieldset class="form-group">
                                <label>Telefone:</label>
                                <br>
                                <input type="text" name="CellPhone" class="form-control"
                                    onkeypress="$(this).mask('(00) 00000-0000')" placeholder="(00) 00000-0000">
                            </fieldset>

                            <fieldset class="form-group">
                                <label for="message">Como nos conheceu? </label>
                                <br>
                                <select id="HowKUS" name="HowKUS" class="form-control" required>
                                    <option value="Pesquisa do Google">Pesquisa do Google</option>
                                    <option value="Internet">Internet</option>
                                    <option value="Redes Sociais">Redes Sociais</option>
                                    <option value="Outros">Outros</option>
                                </select>
                            </fieldset>

                            <fieldset class="form-group">
                                <label for="subject">Assunto: </label>
                                <br>
                                <input id="subject" name="Subject" placeholder="Assunto" value="Orçamento"
                                    class="form-control" required />
                            </fieldset>




                            <fieldset class="form-group">
                                <label for="message">Mensagem: </label>
                                <br>
                                <textarea id="message" name="Message" rows="10" placeholder="Digite aqui"
                                    class="form-control" required></textarea>
                            </fieldset>

                            <fieldset class="form-group">
                                <button type="submit" class="button-success pure-button button-xlarge"> Enviar</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
            <div id="Contato" class="col-lg-12 col-md-12 col-sm-12">


                <div id="TelefoneEmail" class="col-lg-4 col-md-4 col-sm-4">
                    <h4>Entre em Contato</h4>
                    <a href="tel:+5519991028799"><strong>Telefone: </strong> +55 55 19 99102-8799</a>
                    <br>
                    <a href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=maciel16.contact@gmail.com"><strong>Email
                            : </strong>maciel16.contact@gmail.com </a>

                    <h4>Siga-nos nas nossas redes sociais</h4>
                    <a href="https://www.instagram.com/joao_maciel16/?hl=pt-br"><img src="images/SocialMidia/insta.png"
                            width=50px;></a> &nbsp;
                    <a href="https://www.facebook.com/joaomaciel982?ref=bookmarks"> <img src="images/SocialMidia/fb.png"
                            width=50px;></a> &nbsp;
                    <a href="https://www.linkedin.com/in/jo%C3%A3o-pedro-maciel-99168b16a/"><img
                            src="images/SocialMidia/linkedin.png" width=50px;></a> &nbsp;
                    <a href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=maciel16.contact@gmail.com"><img
                            src="images/SocialMidia/mail.png" width=50px;></a> &nbsp;
                    <a href="https://api.whatsapp.com/send?phone=5519991028799"><img
                            src="images/SocialMidia/whatsapp.png" width=50px;></a> &nbsp;
                    <p></p>
                    <br>

                </div>


                <div id="Endereco" class="col-lg-4 col-md-4 col-sm-4">
                    <h4>Endereço</h4>
                    <a
                        href="https://www.google.com/maps/place/R.+Angelo+Cocato,+1201+-+Jardim+Monte+das+Oliveiras,+Nova+Odessa+-+SP,+13386-134/@-22.8092393,-47.3102132,17z/data=!3m1!4b1!4m5!3m4!1s0x94c898120c6605b1:0x12eaab01aada1d9d!8m2!3d-22.8092393!4d-47.3080245">
                        <strong>Rua:</strong> Angelo Cocato, N° 1201 <br>
                        <strong>Bairro:</strong> Jd. Monte das Oliveiras<br>
                        <strong>Cidade:</strong> Nova Odessa - SP<br>
                        <strong>CEP:</strong> 13468-863<br>
                    </a>
                    <br>

                </div>


                <div id="Mapa" class="col-lg-4 col-md-4 col-sm-4">
                    <h4>Google Maps</h4>
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3677.817122713671!2d-47.310213185036105!3d-22.809239285061473!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c898120c6605b1%3A0x12eaab01aada1d9d!2sR.%20Angelo%20Cocato%2C%201201%20-%20Jardim%20Monte%20das%20Oliveiras%2C%20Nova%20Odessa%20-%20SP%2C%2013386-134!5e0!3m2!1spt-BR!2sbr!4v1590764197937!5m2!1spt-BR!2sbr"
                        width="90%" height="50%" frameborder="0" style="border:0;" allowfullscreen=""
                        aria-hidden="false" tabindex="0"></iframe>
                    <br>

                </div>



            </div>

            <div id="footer" class="col-lg-12 col-md-12 col-sm-12">
                <br>
                <p> &copy; JM IT Services 2020/ Desinged by João Maciel </p>
            </div>

        </div>
    </div>





    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <!-- Bootstrap Js CDN -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- Botton Top -->
    <script type="text/javascript" src="js/bttop.js"></script>
    <!-- Side Bar -->
    <script type="text/javascript" src="js/sidebar.js"></script>

    <script type="text/javascript" src="js/mail.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>


</body>

</html>